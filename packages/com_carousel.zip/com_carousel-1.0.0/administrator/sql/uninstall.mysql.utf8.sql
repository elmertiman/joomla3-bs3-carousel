DROP TABLE IF EXISTS `#__carousel_items`;
