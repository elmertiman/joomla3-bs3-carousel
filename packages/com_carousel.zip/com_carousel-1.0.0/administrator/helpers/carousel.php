<?php

/**
 * @version     1.0.0
 * @package     com_carousel
 * @copyright   Copyright (C) 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Elmer Timan <elmer.timan@iat.ac.ae> - http://www.iat.ac.ae
 */
// No direct access
defined('_JEXEC') or die;

/**
 * Carousel helper.
 */
class CarouselHelper {

    /**
     * Configure the Linkbar.
     */
    public static function addSubmenu($vName = '') {
        		JHtmlSidebar::addEntry(
			JText::_('COM_CAROUSEL_TITLE_ITEMS'),
			'index.php?option=com_carousel&view=items',
			$vName == 'items'
		);

    }

    /**
     * Gets a list of the actions that can be performed.
     *
     * @return	JObject
     * @since	1.6
     */
    public static function getActions() {
        $user = JFactory::getUser();
        $result = new JObject;

        $assetName = 'com_carousel';

        $actions = array(
            'core.admin', 'core.manage', 'core.create', 'core.edit', 'core.edit.own', 'core.edit.state', 'core.delete'
        );

        foreach ($actions as $action) {
            $result->set($action, $user->authorise($action, $assetName));
        }

        return $result;
    }


}
