<?php
/**
 * @copyright	Copyright © 2014 - All rights reserved.
 * @license		GNU General Public License v2.0
 * @generator	hhp://xdsoft/joomla-module-generator/
 */
defined('_JEXEC') or die;
$document = JFactory::getDocument();
$modulePath = JURI::base() . 'modules/mod_carousel/';

//Adding CSS Files
$document->addStyleSheet($modulePath.'assets/css/carousel.css');

//$moduleclass_sfx = htmlspecialchars($params->get('moduleclass_sfx'));

require JModuleHelper::getLayoutPath('mod_carousel', $params->get('layout', 'default'));