<?php
defined('_JEXEC') or die;


        // Get the Parameters
        $carousel_params = & JComponentHelper::getParams( 'com_carousel' );
        $number_of_slides = (int)$carousel_params->get( 'number_of_slides' );
         
 $oDB =& JFactory::getDBO();
    $query = "SELECT * FROM #__carousel_items WHERE  state = 1 ORDER BY  ordering LIMIT $number_of_slides "; 
    $oDB->setQuery($query);
    $items = $oDB->loadObjectList();
    $count = (int)count($items);
    if ($count > 0)
    {
        $x = 1;

       
    ?>

    <div data-ride="carousel" class="carousel slide " id="myCarousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
      
         <?php 

         for ($x=0; $x<$count; $x++ )
         {
             if ($x==0)
             {
                 echo '<li class="active" data-slide-to="'.$x.'" data-target="#myCarousel"></li>';
             }
             else
             {
                 echo '<li data-slide-to="'.$x.'" data-target="#myCarousel"></li>';
             }
         }
         ?>
      </ol>
      
      
      <div class="carousel-inner">
         
        <?php 
        $x = 0;
        $active = "";
        foreach ($items as $item)
        {
            if ($x == 0)
               $active = " active ";
            else
               $active = " ";
            
            ?>
            
            <div class="item <?php echo $active; ?>">
                <img class="img-responsive" alt="<?php echo $item->title; ?>" src="<?php echo (!empty($item->image)) ? $item->image : ""; ?>">
                <div class="container">
                  <div class="carousel-caption">
                    <h1><?php echo (!empty($item->caption_header)) ? $item->caption_header : ""; ?></h1>
                    <p><?php echo  (!empty($item->caption_header)) ? $item->caption_description : ""; ?></p>
                    <?php
                    if (!empty($item->caption_button_text))
                    {
                    ?>
                    <p><a role="button" href="<?php echo $item->caption_button_url; ?>" class="btn btn-lg <?php echo $item->caption_button_text_class; ?>"><?php echo $item->caption_button_text; ?></a></p>
                     <?php
                    }
                     ?>
                  </div>
                </div>
            </div>
          
            <?php
            $x++;
        }
        ?>  
      </div>
      <a data-slide="prev" role="button" href="#myCarousel" class="left carousel-control"><span class="glyphicon glyphicon-chevron-left"></span></a>
      <a data-slide="next" role="button" href="#myCarousel" class="right carousel-control"><span class="glyphicon glyphicon-chevron-right"></span></a>
    </div>
    <?php
    }
?>